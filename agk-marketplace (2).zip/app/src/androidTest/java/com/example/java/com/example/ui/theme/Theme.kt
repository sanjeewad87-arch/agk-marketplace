package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val FuturisticDarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    secondary = CyberBlue,
    onSecondary = SolidBlack,
    tertiary = HotPinkGlow,
    background = PitchBlack,
    onBackground = SlateWhite,
    surface = DeepObsidian,
    onSurface = SlateWhite,
    surfaceVariant = SapphireDark,
    onSurfaceVariant = CoolGray,
    outline = GlassBorder
)

private val FuturisticLightColorScheme = lightColorScheme(
    primary = ElectricBlue,
    onPrimary = Color.White,
    secondary = CyberBlue,
    onSecondary = SolidBlack,
    tertiary = HotPinkGlow,
    background = Color(0xFFF1F4F9),
    onBackground = SolidBlack,
    surface = Color.White,
    onSurface = SolidBlack,
    surfaceVariant = Color(0xFFE3EBF6),
    onSurfaceVariant = Color(0xFF455A64),
    outline = Color(0x1F000000)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(), // Supports full toggle!
    dynamicColor: Boolean = false, // Disable to force our customized black & blue palette
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) FuturisticDarkColorScheme else FuturisticLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
