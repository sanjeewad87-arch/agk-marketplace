package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Obsidian Blue & Black futuristic palette
val PitchBlack = Color(0xFF07090E)
val DeepObsidian = Color(0xFF0D111A)
val SolidBlack = Color(0xFF000000)

val CyberBlue = Color(0xFF00E5FF) // Futuristic Bright Cyan
val ElectricBlue = Color(0xFF2979FF) // Active Premium Accent Blue
val SapphireDark = Color(0xFF0F1A30) // Translucent card background base

val SlateWhite = Color(0xFFECEFF1)
val CoolGray = Color(0xFF90A4AE)

val GlassBorder = Color(0x2BFFFFFF) // 17% transparent white for borders
val HotPinkGlow = Color(0xFFFF1744) // Booster ads badge pink accent
val SuccessGreen = Color(0xFF00E676) // Verified seller & seen badges
